# Rubix-22-12-TheStillVariables
Rubix Hackathon CSI-TSEC Problem Statement 3 - Eat Everything You Buy

![image](https://user-images.githubusercontent.com/68726065/159312637-36a43d4c-074e-4d9b-b374-8f5c779b513c.png)

![image](https://user-images.githubusercontent.com/68726065/159312709-caa8cd22-b3f9-4797-ae4d-0cd0c5ed55c2.png)

![image](https://user-images.githubusercontent.com/68726065/159312813-56eb0471-f656-46b6-87bf-05a2e145d542.png)

![image](https://user-images.githubusercontent.com/68726065/159312944-a75a1f1b-1848-40e3-9857-c490086742e5.png)

![image](https://user-images.githubusercontent.com/68726065/159313183-a96b0939-0a94-4270-b13a-3bf5b7904284.png)

![image](https://user-images.githubusercontent.com/68726065/159314184-43f53469-add9-4b55-a9dc-e622007d2053.png)

![image](https://user-images.githubusercontent.com/68726065/159314673-0fa1b10e-7109-4622-8f0c-a158aa8851e6.png)

![image](https://user-images.githubusercontent.com/68726065/159314907-34453649-43bd-4c1a-8c80-23ce9e830e92.png)

![image](https://user-images.githubusercontent.com/68726065/159315458-2b949113-4fce-48cc-a748-c30c276ff5fc.png)
